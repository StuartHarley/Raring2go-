# Raring2go! Codex Build Pack

Start with `AGENTS.md`, then `docs/BUILD_SPEC.md`. The pack translates Product Architecture v1.2 into an implementation-ready structure for a GitHub/Codex workflow.

Recommended first milestone: Foundation + Identity/RBAC + Franchise/Advertiser core + one complete Edition vertical slice. Do not attempt all 80+ editions until the single-territory print-and-digital workflow is proven.
